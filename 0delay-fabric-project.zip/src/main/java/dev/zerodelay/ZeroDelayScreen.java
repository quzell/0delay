package dev.zerodelay;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ZeroDelayScreen extends Screen {
    private final double tps;

    protected ZeroDelayScreen(double tps) {
        super(Component.literal("0delay"));
        this.tps = tps;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);
        int left = (this.width - 240) / 2;
        int top = (this.height - 120) / 2;
        graphics.fill(left, top, left + 240, top + 120, 0xEE171221);
        graphics.fill(left, top, left + 240, top + 3, 0xFF9B5DE5);
        graphics.drawCenteredString(this.font, "0delay", this.width / 2, top + 14, 0xFFCBA6F7);
        graphics.drawCenteredString(this.font, "Server TPS: " + String.format(java.util.Locale.ROOT, "%.1f", tps),
                this.width / 2, top + 42, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, "No client-side attack delay is added.",
                this.width / 2, top + 62, 0xFFB9B3C6);
        graphics.drawCenteredString(this.font, "Attack cooldown remains server/game controlled.",
                this.width / 2, top + 78, 0xFFB9B3C6);
        graphics.drawCenteredString(this.font, "Change GUI key in Options > Controls.",
                this.width / 2, top + 98, 0xFFCBA6F7);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
