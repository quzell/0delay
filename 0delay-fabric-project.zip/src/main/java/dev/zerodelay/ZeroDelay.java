package dev.zerodelay;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public class ZeroDelay implements ModInitializer {
    public static final String MOD_ID = "zerodelay";
    private static long lastSampleNanos = System.nanoTime();
    private static int ticksInWindow = 0;
    private static double estimatedTps = 20.0;

    public record TpsPayload(double tps) implements CustomPacketPayload {
        public static final Type<TpsPayload> TYPE =
                new Type<>(ResourceLocation.fromNamespaceAndPath(MOD_ID, "tps"));
        public static final StreamCodec<RegistryFriendlyByteBuf, TpsPayload> CODEC =
                StreamCodec.of((buf, value) -> buf.writeDouble(value.tps()),
                        buf -> new TpsPayload(buf.readDouble()));

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(TpsPayload.TYPE, TpsPayload.CODEC);
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
    }

    private void onServerTick(MinecraftServer server) {
        ticksInWindow++;
        long now = System.nanoTime();
        long elapsed = now - lastSampleNanos;
        if (elapsed >= 1_000_000_000L) {
            estimatedTps = Math.min(20.0, ticksInWindow * 1_000_000_000.0 / elapsed);
            ticksInWindow = 0;
            lastSampleNanos = now;
            TpsPayload payload = new TpsPayload(estimatedTps);
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (ServerPlayNetworking.canSend(player, TpsPayload.TYPE)) {
                    ServerPlayNetworking.send(player, payload);
                }
            }
        }
    }
}
