# 0delay — Fabric 1.21.11 project

This is a **source project**, not a precompiled `.jar`. It contains a purple GUI, a configurable key binding (default Right Shift), and a server-side TPS sample sent to compatible clients.

## Requirements
- JDK 21
- Minecraft 1.21.11
- Fabric Loader 0.18.1 or newer
- Fabric API matching Minecraft 1.21.11

## Build on Windows
1. Install JDK 21.
2. Open this folder in a terminal.
3. Run `gradle build` if Gradle is installed.
4. The resulting jar should appear in `build/libs/`.

## Install
- Put the built `0delay-0.1.0.jar` on both the client and the Fabric server.
- The client key can be changed in Options → Controls → Key Binds.
- The GUI opens with the configured key (default Right Shift).

## Notes
- The server component measures tick rate over one-second windows and sends it to modded clients.
- TPS readings are estimates, not a guarantee of exact server performance.
- This mod does not bypass attack cooldowns or force attacks; the game/server remain authoritative.
- This project has not been compiled or runtime-tested in this environment. Review and build it before use.
